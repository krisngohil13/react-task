// src/components/Header.js
import React from 'react';
import { useSpring, animated } from '@react-spring/web';

const Header = () => {
  // Fade-in animation
  const fadeIn = useSpring({
    from: { opacity: 0, transform: 'translateY(-20px)' },
    to: { opacity: 1, transform: 'translateY(0)' },
    config: { duration: 800 },
  });

  return (
    <animated.header style={fadeIn} className="header bg-primary text-white py-3 mb-4">
      <div className="container text-center">
        <h1>React Local & Session Storage App</h1>
        <p>Persist data using Local Storage and Session Storage</p>
      </div>
    </animated.header>
  );
};

export default Header;
