// src/components/CounterComponent.js
import React, { useState, useEffect } from 'react';

const CounterComponent = () => {
  // Initialize counter state with value from Local Storage
  const [counter, setCounter] = useState(() => {
    const savedCounter = localStorage.getItem('counter');
    return savedCounter ? Number(savedCounter) : 0;
  });

  // Update Local Storage whenever the counter changes
  useEffect(() => {
    localStorage.setItem('counter', counter);
  }, [counter]);

  // Increment counter
  const handleIncrement = () => {
    setCounter((prevCounter) => prevCounter + 1);
  };

  // Reset counter
  const handleReset = () => {
    setCounter(0);
    localStorage.removeItem('counter');
  };

  return (
    <div className="counter-component">
      <h2>Counter (Local Storage)</h2>
      <p>Counter Value: {counter}</p>
      <button onClick={handleIncrement}>Increment Counter</button>
      <button onClick={handleReset}>Reset Counter</button>
    </div>
  );
};

export default CounterComponent;
