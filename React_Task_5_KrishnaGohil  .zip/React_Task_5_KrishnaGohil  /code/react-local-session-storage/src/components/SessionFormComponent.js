import React, { useState, useEffect } from 'react';

const hashPassword = async (password) => {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((byte) => byte.toString(16).padStart(2, '0')).join('');
};

const SessionFormComponent = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    const savedEmail = sessionStorage.getItem('email');
    if (savedEmail) setEmail(savedEmail);
  }, []);

  // Form submission with validation
  const handleSave = async () => {
    if (!email && !password) {
      setError('Both email and password are required!');
    } else if (!email) {
      setError('Email is required!');
    } else if (!password) {
      setError('Password is required!');
    } else {
      setError('');  // Clear error if fields are valid
      const hashedPassword = await hashPassword(password);
      sessionStorage.setItem('email', email);
      sessionStorage.setItem('hashedPassword', hashedPassword);
      alert('Email and hashed password saved in Session Storage!');
    }
  };

  const handleClear = () => {
    sessionStorage.removeItem('email');
    sessionStorage.removeItem('hashedPassword');
    setEmail('');
    setPassword('');
    alert('Session Storage cleared!');
  };

  return (
    <div className="session-form-component">
      <h2>Email & Password Form (Session Storage)</h2>
      <input
        type="email"
        placeholder="Enter email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      <input
        type="password"
        placeholder="Enter password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      {error && <p className="error-message">{error}</p>}
      <button onClick={handleSave}>Save Data</button>
      <button onClick={handleClear}>Clear Data</button>
    </div>
  );
};

export default SessionFormComponent;
