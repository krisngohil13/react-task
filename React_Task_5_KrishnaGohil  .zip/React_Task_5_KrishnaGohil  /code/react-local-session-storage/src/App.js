import React from "react";
import CounterComponent from "./components/CounterComponent";
import SessionFormComponent from "./components/SessionFormComponent";
import './styles/style.css';  // Import CSS for styles

const App = () => {
  return (
    <div className="main-container">
      {/* Full-Screen Image Div */}
      <div className="image-div">
        <img src="/images/image-5.jpg" alt="Background Image" />
      </div>

      {/* Full-Height and Full-Width Form Container on the Right Side */}
      <div className="form-container">
        <div className="form-box">
          <CounterComponent />
        </div>
        <div className="form-box">
          <SessionFormComponent />
        </div>
      </div>
    </div>
  );
};

export default App;
