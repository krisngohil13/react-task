import './App.css';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Custom Formik Form</h1>
        <Formik
          initialValues={{
            email: '',
            password: '',
          }}
          validationSchema={Yup.object({
            email: Yup.string()
              .email('Invalid email address')
              .required('Email is required'),
            password: Yup.string()
              .min(6, 'Password must be at least 6 characters')
              .max(12, 'Password cannot be more than 12 characters')
              .required('Password is required'),
          })}
          onSubmit={(values) => {
            alert(JSON.stringify(values, null, 2));
          }}
        >
          {({ touched, errors }) => (
            <Form>
              {/* Email Field */}
              <div className="input-field">
                <label htmlFor="email">Email</label>
                <Field
                  name="email"
                  type="email"
                  placeholder="Enter your email"
                  className="form-control"
                />
                {/* Error Message for Email */}
                {touched.email && errors.email && (
                  <div className="error-message show">{errors.email}</div>
                )}
              </div>

              {/* Password Field */}
              <div className="input-field">
                <label htmlFor="password">Password</label>
                <Field
                  name="password"
                  type="password"
                  placeholder="Enter your password"
                  className="form-control"
                />
                {/* Error Message for Password */}
                {touched.password && errors.password && (
                  <div className="error-message show">{errors.password}</div>
                )}
              </div>

              {/* Submit Button */}
              <button type="submit">Submit</button>
            </Form>
          )}
        </Formik>
      </header>
    </div>
  );
}

export default App;
