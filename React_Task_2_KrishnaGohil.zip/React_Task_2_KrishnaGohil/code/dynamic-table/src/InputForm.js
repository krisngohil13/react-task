import React, { useState } from 'react';

const InputForm = ({ onAddData }) => {
  const [formData, setFormData] = useState({ name: '', age: '', city: '' });
  const [error, setError] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Reset error before validating
    setError('');

    // Check if any field is empty and set an error message
    if (!formData.name || !formData.age || !formData.city) {
      setError('All fields are required.');
      return;
    }

    // Check if age is a positive number (parse it to a number)
    if (Number(formData.age) <= 0 || isNaN(formData.age)) {
      setError('Age must be a positive number.');
      return;
    }

    // If validation passes, call onAddData and reset form
    onAddData(formData);
    setFormData({ name: '', age: '', city: '' });
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        name="name"
        placeholder="Name"
        value={formData.name}
        onChange={handleChange}
      />
      <input
        type="number"
        name="age"
        placeholder="Age"
        value={formData.age}
        onChange={handleChange}
      />
      <input
        type="text"
        name="city"
        placeholder="City"
        value={formData.city}
        onChange={handleChange}
      />
      <button type="submit">Add</button>
      
      {/* Display the error message with CSS class */}
      {error && <p className="error-message">{error}</p>}
    </form>
  );
};

export default InputForm;
