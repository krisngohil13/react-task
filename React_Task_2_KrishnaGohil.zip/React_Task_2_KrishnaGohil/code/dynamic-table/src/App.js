// src/App.js
import React, { useState } from 'react';
import DynamicTable from './DynamicTable';
import InputForm from './InputForm';
import './App.css';

function App() {
  const [data, setData] = useState([]);

  const handleAddData = (newData) => {
    setData([...data, newData]);
  };

  const handleDelete = (index) => {
    const newData = data.filter((_, i) => i !== index);
    setData(newData);
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>Dynamic Table</h1>
        <InputForm onAddData={handleAddData} />
        <DynamicTable data={data} onDelete={handleDelete} />
      </header>
    </div>
  );
}

export default App;