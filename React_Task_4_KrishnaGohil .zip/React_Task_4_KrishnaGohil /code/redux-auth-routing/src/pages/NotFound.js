// src/pages/NotFound.js
import React from 'react';
import { Link } from 'react-router-dom';
import '../assets/styles.css';
import '../assets/animations.css';

const NotFound = () => {
  return (
    <div className="container fade-in">
      <h2>404 - Page Not Found</h2>
      <p>The page you are looking for does not exist.</p>
      <Link to="/" style={{ color: '#4caf50', textDecoration: 'underline' }}>Go back to Home</Link>
    </div>
  );
};

export default NotFound;
