import React from 'react';
import { useNavigate } from 'react-router-dom';
import '../assets/styles.css';

const Home = () => {
  const navigate = useNavigate();

  const handleNavigate = () => {
    navigate('/login');
  };

  return (
    <div className="container-wrapper">
      <div className="container">
        <h1>Welcome to Home</h1>
        <p>Experience a smooth and animated user interface.</p>
        <button onClick={handleNavigate} className="home-btn-gradient">
          Go to Login
        </button>
      </div>
    </div>
  );
};

export default Home;
