// src/components/Login.js
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { login } from '../features/auth/authSlice';
import { useNavigate } from 'react-router-dom';
import '../assets/styles.css';
import '../assets/animations.css';

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleLogin = () => {
    // Basic validation for empty fields
    if (username.trim() === '') {
      setError('Username is required!');
      return;
    }

    if (password.trim() === '') {
      setError('Password is required!');
      return;
    }

    // Username validation: must be at least 5 characters and contain only alphanumeric characters or underscores
    if (!/^[a-zA-Z0-9_]{5,}$/.test(username)) {
      setError('Username must be at least 5 characters long and contain only letters, numbers, or underscores.');
      return;
    }

    // Password validation: must be at least 6 characters long
    if (password.length < 6) {
      setError('Password must be at least 6 characters long!');
      return;
    }

    setError('');
    dispatch(login({ username, password })); // Dispatching both username and password
    navigate('/dashboard');
  };

  const handleUsernameChange = (e) => {
    setUsername(e.target.value);
    if (e.target.value.trim() !== '') {
      setError('');
    }
  };

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
    if (e.target.value.trim() !== '') {
      setError('');
    }
  };

  return (
    <div className="container bounce-in">
      <h2>Login</h2>
      
      {/* Username input */}
      <input
        type="text"
        placeholder="Enter your username"
        value={username}
        onChange={handleUsernameChange}
        className={error ? 'input-error' : ''}
      />
      
      {/* Password input */}
      <input
        type="password"
        placeholder="Enter your password"
        value={password}
        onChange={handlePasswordChange}
        className={error ? 'input-error' : ''}
      />
      
      {/* Error message */}
      {error && <p className="error-message">{error}</p>}
      
      {/* Login button */}
      <button
        onClick={handleLogin}
        className={`login-button ${username.trim() === '' || password.trim() === '' ? 'btn-error-gradient' : 'btn-normal'}`}
      >
        Login
      </button>
    </div>
  );
};

export default Login;
