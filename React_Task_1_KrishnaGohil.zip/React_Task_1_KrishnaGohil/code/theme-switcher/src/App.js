// src/App.js
import React, { useContext } from 'react';
import { ThemeContext } from './ThemeContext';
import './App.css';
import { FaSun, FaMoon } from 'react-icons/fa'; // Import the icons

function App() {
  const { theme, toggleTheme } = useContext(ThemeContext);

  return (
    <div className={`app ${theme}`}>
      <header className="app-header">
        <h1>Theme Switcher</h1>
        <label className="switch">
          <input
            type="checkbox"
            onChange={toggleTheme}
            checked={theme === 'dark'}
          />
          <span className="slider round">
            <FaSun className="sun-icon" /> {/* Sun icon inside the slider */}
            <FaMoon className="moon-icon" /> {/* Moon icon inside the slider */}
          </span>
        </label>
      </header>
    </div>
  );
}

export default App;
